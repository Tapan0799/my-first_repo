# -*- coding: utf-8 -*-
"""
Created on Sat Jul  3 16:09:36 2021

@author: Kiran
"""

#numpy works on n-dimensional arrays

import numpy as np

a = np.array([0,1,2,3,4,5]) #list as an argument and creates an array

print(a)

a1 = np.arange(10) # create 0 to 9 elements of array

print(a1)

mylist = range(1000) # mylist will contain 0 to 999

#linearspace

#eye gives identity matrix

#diag will put the list elements only in the diagonal and
#the other columns and rowsa fillup with 0's
#dtype gives data type


