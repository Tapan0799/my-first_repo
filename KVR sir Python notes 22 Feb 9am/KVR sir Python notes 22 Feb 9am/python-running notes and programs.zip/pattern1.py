# -*- coding: utf-8 -*-
"""
Created on Thu Jun 10 11:27:05 2021

@author: Kiran
"""

n = 5
for i in range(n):
    for j in range(i+1):
          print('*',end='')
    print()